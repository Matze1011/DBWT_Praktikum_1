create
    definer = root@localhost procedure anzahlanmeldung(IN benutzerid int)
BEGIN
    UPDATE
        benutzer
    SET
        anzahlanmeldungen=anzahlanmeldungen+1
    WHERE
            id = benutzerid;
END;

