create definer = root@localhost view view_anmeldungen as
select `emensawerbeseite`.`benutzer`.`anzahlanmeldungen` AS `anzahlanmeldungen`
from `emensawerbeseite`.`benutzer`
order by `emensawerbeseite`.`benutzer`.`anzahlanmeldungen` desc;

