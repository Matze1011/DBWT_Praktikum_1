create definer = root@localhost view view_kategoriegerichte_vegetarisch as
select `g`.`name` AS `vegetarische_gerichte`, `k`.`name` AS `kategorie`
from (`emensawerbeseite`.`kategorie` `k`
         left join (`emensawerbeseite`.`gericht` `g` left join `emensawerbeseite`.`gericht_hat_kategorie` `ghk` on (`ghk`.`gericht_id` = `g`.`id` and `g`.`vegetarisch` = 1))
                   on (`ghk`.`kategorie_id` = `k`.`id`))
union
select `g`.`name` AS `vegetarische_gerichte`, `k`.`name` AS `kategorie`
from ((`emensawerbeseite`.`gericht` `g` left join `emensawerbeseite`.`gericht_hat_kategorie` `ghk` on (`ghk`.`gericht_id` = `g`.`id`))
         left join `emensawerbeseite`.`kategorie` `k` on (`ghk`.`kategorie_id` = `k`.`id`))
where `g`.`vegetarisch` = 1;

